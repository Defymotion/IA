@echo off
title Vigilante InventorIA - no cerrar
cd /d "%~dp0.."
".venv\Scripts\python.exe" "scripts\vigilante.py"
pause
