---
name: inventoria
description: Trabajar con Autodesk Inventor en la PC del usuario con el método InventorIA de DEFYMOTION (vigilante, scripts Python por COM) para diseñar grippers de chapa, planos A4/DXF y simular celdas robotizadas con videos. Usar cuando pidan algo en Inventor, un gripper, planos o una simulación/animación.
---

# InventorIA (DEFYMOTION)

1. Leé `Documents\InventorIA\CLAUDE.md` de la PC vinculada (traelo con el puente). Ahí están las reglas
   obligatorias y el protocolo del vigilante.
2. Leé `docs\Guia_IA_Inventor.md` y, si es una simulación, `docs\SIMULACIONES.md`. Para ver el estado de cada
   proyecto, `docs\InventorIA_contexto.md`.
3. Comprobá que el vigilante esté vivo: `_pedidos\vigilante.activo` reciente o `verificacion.txt`. Usá siempre un
   número de pedido nuevo.
4. Releva antes de construir; probá en chico (fotos, 1 cuadro) antes del render completo; mirá el resultado antes
   de entregarlo.
5. Nunca modifiques originales ni cierres documentos del usuario. Al terminar, actualizá `InventorIA_contexto.md`.
