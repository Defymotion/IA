# InventorIA — Diseño y simulación en Autodesk Inventor con IA (DEFYMOTION)

Repositorio para que cualquier integrante del equipo pueda trabajar con **Claude**, desde **su propia PC**, como
lo hicimos en el proyecto InventorIA. Claude puede:

- diseñar grippers de chapa paramétricos;
- hacer planos A4, DXF de corte y listas de materiales;
- relevar layouts de clientes;
- simular celdas robotizadas y entregar videos Full HD, horizontales o verticales.

Inventor corre en tu PC. Claude no tiene acceso directo a Inventor: deja "pedidos" (scripts Python) en una carpeta y
un programa chico, el **vigilante**, los ejecuta en tu Inventor y le devuelve los resultados.

```
Claude (en la nube) ──► copia script + pedido ──► Documents\InventorIA\_pedidos\pNNN.json
                                                   │  vigilante.bat (en tu PC) lo ejecuta con Inventor
Claude ◄── trae resultado / imágenes / cuadros ◄──┘  pNNN.resultado.json, PNG, ZIP
```

## Inicio rápido (resumen; el detalle está en [INSTALACION.md](INSTALACION.md))

1. Tener **Windows + Autodesk Inventor 2025** con licencia, **Python 3.13** y la **app de escritorio de Claude**.
2. Descargar este repositorio y ejecutar **`instalar.bat`**. Crea `Documents\InventorIA`, copia todo e instala
   las dependencias.
3. Abrir **Inventor** y después el acceso directo **"Vigilante InventorIA"** del escritorio. Dejar las dos ventanas abiertas.
4. En la app de Claude, abrir una tarea **vinculada a esta computadora** y darle acceso a la carpeta
   `Documents\InventorIA`.
5. Pegar el mensaje de arranque de [INSTALACION.md](INSTALACION.md#6-primer-mensaje-a-claude) (le pide leer
   `CLAUDE.md`).

## Contenido

| Ruta | Qué es |
|---|---|
| `CLAUDE.md` | **Instrucciones para la IA**: reglas, protocolo del vigilante y por dónde empezar. La IA lo lee primero |
| `INSTALACION.md` | Instalación paso a paso en una PC nueva y conexión con Claude |
| `docs/Guia_IA_Inventor.md` | **Guía maestra**: todo el método para diseño, planos y animaciones (muy detallada) |
| `docs/SIMULACIONES.md` | Receta concreta para generar simulaciones y videos (comandos, tiempos, variantes) |
| `docs/SCRIPTS.md` | Índice de todos los scripts y para qué sirve cada uno |
| `docs/Receta_IA_Inventor.md` | Receta técnica original (API de Inventor, planos, robots) |
| `docs/InventorIA_contexto.md` | Historial y estado de los proyectos hechos (ADECO, NewPack2, KR30, DosHermanos…) |
| `inventor-assistant-portable/server/` | Librería Python de Inventor (`inventor_mcp.py`) y motor de grippers |
| `inventor-assistant-portable/scripts/` | Un script por tarea + `vigilante.py` / `vigilante.bat` + `verificar_instalacion` |
| `instalar.bat` / `instalar.ps1` | Instalador para una PC nueva |
| `plantillas/pedido_ejemplo.json` | Formato de un pedido para el vigilante |

## Qué NO viene en el repositorio (y hay que conseguir aparte)

- **Modelos CAD** (son pesados y propios de cada proyecto): layouts de clientes, robots, comerciales.
  - Las simulaciones con KUKA KR 140 usan `Documents\InventorIA\12_ADECO2\KUKA\KUKA-KR_140_R3200_2_PA-ASM.iam`,
    con sus eslabones V01…V05. Copiarlo desde el servidor de proyectos de DEFYMOTION.
  - Ver [INSTALACION.md §7](INSTALACION.md#7-modelos-cad-necesarios).
- El entorno Python (`.venv`): lo crea el instalador en cada PC.

## Reglas de oro (resumen)

1. Nunca tocar originales: se trabaja sobre copias o en `Documents\InventorIA\Generados\`.
2. Editar lo que ya existe en vez de rehacerlo; en videos, re-renderizar sólo el tramo que cambia.
3. Medir antes de suponer y mirar el resultado (imagen, PDF o cuadro) antes de darlo por bueno.
4. Probar en chico antes de lo caro: una foto, después 1 cuadro, después el render completo.
5. Español rioplatense, mm, hojas A4. Videos Full HD con "Luz suave", sombras y planos ocultos.
